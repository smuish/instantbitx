<div class="col-md-12">
    <div class="card">
        <div class="header">
            <h3 class="title">Email settings</h3>
            <p class="">Email gateway</p>
        </div>
         <div class="content">


        </div>
    </div>
</div>
                