<?php 

    
?>

<style>
.icons{

    display:none;
}
</style>
<div class="col-md-12">
    <div class="card">
        <div class="header">
            <div class="inner-menu">
                <div>
                    <h3 class="title">Daily Orders</h3>
                    <p class="">Order list</p>
                </div>
                <div>
                    <a href=".?page=neworderform" class="btn btn-info"><i class="ti-plus"></i> Add Order</a>
                </div>
            </div>
        </div>
         <div class="content">

        <div class="content table-responsive table-full-width">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th></th>
											<th>ID</th>
                                            <th>Order Number</th>
                                            <th>Order Type</th>
                                            <th>Customer</th>
                                            <th>Payment Method</th>
                                            <th>Amount (GHC)</th>
                                            <th>Status</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><input type="checkbox"></td>
                                            <td>1030</td>
                                            <td>08900000</td>
                                            <td>Sell</td>
                                        	<td><a href=".?page=customerdetails">Joe</a></td>
                                            <td>Mobile Money</td>
                                            <td>2,800</td>
                                        	<td><span>Pending</span></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td><input type="checkbox"></td>
                                            <td>1030</td>
                                            <td>08900000</td>
                                            <td>Sell</td>
                                        	<td><a href=".?page=customerdetails">Joe</a></td>
                                            <td>Mobile Money</td>
                                            <td>2,800</td>
                                        	<td><span>Pending</span></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td><input type="checkbox"></td>
                                            <td>1030</td>
                                            <td>08900000</td>
                                            <td>Sell</td>
                                        	<td><a href=".?page=customerdetails">Joe</a></td>
                                            <td>Mobile Money</td>
                                            <td>2,800</td>
                                        	<td><span>Pending</span></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td><input type="checkbox"></td>
                                            <td>1030</td>
                                            <td>08900000</td>
                                            <td>Sell</td>
                                        	<td><a href=".?page=customerdetails">Joe</a></td>
                                            <td>Mobile Money</td>
                                            <td>2,800</td>
                                        	<td><span>Pending</span></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td><input type="checkbox"></td>
                                            <td>1030</td>
                                            <td>08900000</td>
                                            <td>Sell</td>
                                        	<td><a href=".?page=customerdetails">Joe</a></td>
                                            <td>Mobile Money</td>
                                            <td>2,800</td>
                                        	<td><span>Pending</span></td>
                                            <td></td>
                                        </tr>
                                    </tbody>
                                </table>

                            </div>
						</div>
    </div>
</div>
                