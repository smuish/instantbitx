
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h3 class="title">KYC / Identiy</h3>
                                <p class="">User verification documents</p>
                            </div>
                            <div class="content table-responsive table-full-width">
                            <div class="card card-primary m-0 m-md-4 my-4 m-md-0 shadow">
        <div class="card-body">
            <form method="post" action="https://finounce.bugfinder.net/admin/identity-form/action" class="form-row align-items-center ">
                <input type="hidden" name="_token" value="6bFh9EckwwycXLziruj3cj1aLrL8qpb8rJLBmZN7">
                    <div class="form-group col-md-3">
                        <label class="d-block">Address Verification</label>
                        <div class="custom-switch-btn">
                            <input type="hidden" value="1" name="address_verification">
                            <input type="checkbox" name="address_verification" class="custom-switch-checkbox" id="address_verification" value="0" checked="">
                            <label class="custom-switch-checkbox-label" for="address_verification">
                                <span class="custom-switch-checkbox-inner"></span>
                                <span class="custom-switch-checkbox-switch"></span>
                            </label>
                        </div>
                    </div>

                    <div class="form-group col-md-3">
                        <label class="d-block">Identity Verification</label>
                        <div class="custom-switch-btn">
                            <input type="hidden" value="1" name="identity_verification">
                            <input type="checkbox" name="identity_verification" class="custom-switch-checkbox" id="identity_verification" value="0" checked="">
                            <label class="custom-switch-checkbox-label" for="identity_verification">
                                <span class="custom-switch-checkbox-inner"></span>
                                <span class="custom-switch-checkbox-switch"></span>
                            </label>
                        </div>
                    </div>
                    <div class="form-group col-md-2">
                            <button type="submit" class="btn btn-primary btn-block  btn-rounded mx-2 mt-4">
                                <span>Save Changes</span></button>
                    </div>




            </form>
        </div>
    </div>

                </div>
            </div>
        </div>
